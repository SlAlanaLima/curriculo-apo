
document.addEventListener("DOMContentLoaded", function () {
  const dataNascimentoInput = document.getElementById("dataNascimento");
  const idadeInput = document.getElementById("idade");

  dataNascimentoInput.addEventListener("change", function () {
    const dataNascimento = new Date(this.value);
    const hoje = new Date();
    let idade = hoje.getFullYear() - dataNascimento.getFullYear();
    const mesAtual = hoje.getMonth();
    const mesNasc = dataNascimento.getMonth();

    if (mesAtual < mesNasc || (mesAtual === mesNasc && hoje.getDate() < dataNascimento.getDate())) {
      idade--;
    }

    idadeInput.value = !isNaN(idade) ? idade : "";
  });

  document.getElementById("addExperiencia").addEventListener("click", function () {
    const input = document.createElement("input");
    input.type = "text";
    input.className = "form-control mb-2";
    input.name = "experiencia[]";
    input.placeholder = "Nova Experiência Profissional";
    document.getElementById("experiencias").appendChild(input);
  });

  document.getElementById("addReferencia").addEventListener("click", function () {
    const input = document.createElement("input");
    input.type = "text";
    input.className = "form-control mb-2";
    input.name = "referencia[]";
    input.placeholder = "Nova Referência Pessoal";
    document.getElementById("referencias").appendChild(input);
  });

  document.getElementById("formDados").addEventListener("submit", function (e) {
    e.preventDefault();

    const nome = document.getElementById("nome").value;
    const dataNascimento = document.getElementById("dataNascimento").value;
    const idade = document.getElementById("idade").value;

    const experiencias = Array.from(document.querySelectorAll('[name="experiencia[]"]')).map(e => e.value);
    const referencias = Array.from(document.querySelectorAll('[name="referencia[]"]')).map(e => e.value);

    const doc = new window.jspdf.jsPDF();
    let y = 10;

    doc.setFontSize(16);
    doc.text("Currículo", 105, y, { align: "center" });
    y += 10;

    doc.setFontSize(12);
    doc.text(`Nome: ${nome}`, 10, y); y += 10;
    doc.text(`Data de Nascimento: ${dataNascimento}`, 10, y); y += 10;
    doc.text(`Idade: ${idade}`, 10, y); y += 10;

    doc.text("Experiências Profissionais:", 10, y); y += 10;
    experiencias.forEach(exp => {
      doc.text(`- ${exp}`, 15, y); y += 10;
    });

    doc.text("Referências Pessoais:", 10, y); y += 10;
    referencias.forEach(ref => {
      doc.text(`- ${ref}`, 15, y); y += 10;
    });

    doc.save("curriculo.pdf");
  });
});
